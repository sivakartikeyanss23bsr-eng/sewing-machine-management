import { useState } from "react";
import api from "../api";

function OtpVerify() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");

  const verifyOtp = async () => {
    try {
      await api.post("/api/auth/verify-otp", { email, otp });
      alert("Email verified successfully");
    } catch (err) {
      alert("Invalid OTP");
    }
  };

  return (
    <div>
      <input 
        placeholder="Email" 
        value={email}
        onChange={e => setEmail(e.target.value)} 
      />
      <input 
        placeholder="OTP" 
        value={otp}
        onChange={e => setOtp(e.target.value)} 
      />
      <button onClick={verifyOtp}>Verify OTP</button>
    </div>
  );
}

export default OtpVerify;
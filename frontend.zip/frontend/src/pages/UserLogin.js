import { useState } from "react";
import api from "../api";
import { useNavigate } from "react-router-dom";

function UserLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const login = async () => {
    const res = await api.post("/api/auth/login", { email, password });

    if (res.data.role !== "user") {
      alert("Not a user account");
      return;
    }

    localStorage.setItem("token", res.data.token);
    navigate("/home");
  };

  return (
    <div className="container">
      <h2>User Login</h2>
      <input placeholder="Email" onChange={e => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" onChange={e => setPassword(e.target.value)} />
      <button onClick={login}>Login</button>
    </div>
  );
}

export default UserLogin;

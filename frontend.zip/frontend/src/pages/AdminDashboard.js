import { useEffect, useState } from "react";
import api from "../api";

function AdminDashboard() {
  const [services, setServices] = useState([]);

  console.log("AdminDashboard rendered");

  useEffect(() => {
    console.log("Calling /services API");

    api.get("/services")
      .then(res => {
        console.log("API success:", res.data);
        setServices(res.data);
      })
      .catch(err => {
        console.error("API error:", err);
      });
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Admin Dashboard – Service Requests</h2>

      {services.length === 0 && <p>No service requests found</p>}

      {services.map(service => (
        <div key={service.service_id} style={{ border: "1px solid #ccc", margin: "10px", padding: "10px" }}>
          <h4>{service.name}</h4>
          <p>Email: {service.email}</p>
          <p>Phone: {service.phone}</p>
          <p>Machine: {service.machine_model}</p>
          <p>Complaint: {service.complaint}</p>
        </div>
      ))}
    </div>
  );
}

export default AdminDashboard;

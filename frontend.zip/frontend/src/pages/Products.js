import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import ProductCard from "../components/ProductCard";

function Products() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    api.get("/api/products")
      .then(res => {
        console.log("PRODUCT DATA:", res.data); // 👈 debug
        setProducts(res.data);
      })
      .catch(err => console.error(err));
  }, []);

  return (
    <div style={{ minHeight: '100vh', fontFamily: 'Arial, sans-serif' }}>
      <main style={{ padding: '1rem', maxWidth: '1200px', margin: '0 auto' }}>
        <div className="products-container grid">
          {products.length === 0 && <p>No products found</p>}

          {products.map(product => (
            <ProductCard key={product.product_id} product={product} />
          ))}
        </div>
      </main>
    </div>
  );
}

export default Products;

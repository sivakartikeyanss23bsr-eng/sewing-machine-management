import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

function FirstHome() {
  const navigate = useNavigate();
  const [companyInfo, setCompanyInfo] = useState(null);

  useEffect(() => {
    // Fetch company information from the database
    api.get("/api/company")
      .then(res => setCompanyInfo(res.data))
      .catch(err => console.error("Error fetching company info:", err));
  }, []);

  return (
    <div style={{ textAlign: 'center', padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1>Welcome to Sewing Machine Company</h1>

      {companyInfo && (
        <div style={{ margin: '2rem 0', padding: '1rem', border: '1px solid #ccc', borderRadius: '8px' }}>
          <h2>About Us</h2>
          <p><strong>Name:</strong> {companyInfo.name}</p>
          <p><strong>Description:</strong> {companyInfo.description}</p>
          <p><strong>Contact:</strong> {companyInfo.contact}</p>
          <p><strong>Address:</strong> {companyInfo.address}</p>
        </div>
      )}

      <div style={{ margin: '2rem 0' }}>
        <h3>Please login or register to continue</h3>
        <button
          onClick={() => navigate('/login')}
          style={{ margin: '0 1rem', padding: '0.5rem 1rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Login
        </button>
        <button
          onClick={() => navigate('/register')}
          style={{ margin: '0 1rem', padding: '0.5rem 1rem', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Register
        </button>
      </div>
    </div>
  );
}

export default FirstHome;

function Orders() {
  return (
    <div className="container">
      <h2>Order History</h2>
      <p>Status: Delivered</p>
    </div>
  );
}
export default Orders;

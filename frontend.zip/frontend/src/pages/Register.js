import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import api from "../api";

import '../styles/Register.css';

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    gender: "",
    phone: "",
    dob: "",
    address: ""
  });
  const [errors, setErrors] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [passwordMatch, setPasswordMatch] = useState(true);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error for this field when user types
    if (errors.length > 0) {
      setErrors([]);
    }
  };

  const validateForm = () => {
    const validationErrors = [];
    
    if (!form.name) validationErrors.push("Name is required");
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      validationErrors.push("Valid email is required");
    }
    if (!form.password) {
      validationErrors.push("Password is required");
    } else if (form.password.length < 6) {
      validationErrors.push("Password must be at least 6 characters");
    }
    
    // Check if passwords match
    if (form.password !== form.confirmPassword) {
      validationErrors.push("Passwords do not match");
      setPasswordMatch(false);
    } else {
      setPasswordMatch(true);
    }
    if (!['Male', 'Female', 'Other'].includes(form.gender)) {
      validationErrors.push("Please select a gender");
    }
    if (!form.phone || !/^\d{10,15}$/.test(form.phone)) {
      validationErrors.push("Valid phone number is required");
    }
    if (!form.dob) {
      validationErrors.push("Date of birth is required");
    } else {
      // Check if user is at least 13 years old
      const dob = new Date(form.dob);
      const today = new Date();
      const minAgeDate = new Date(
        today.getFullYear() - 13,
        today.getMonth(),
        today.getDate()
      );
      if (dob > minAgeDate) {
        validationErrors.push("You must be at least 13 years old to register");
      }
    }
    if (!form.address || form.address.length < 10) {
      validationErrors.push("Address must be at least 10 characters");
    }

    setErrors(validationErrors);
    return validationErrors.length === 0;
  };

  const sendOTP = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await api.post("/api/register/send-otp", { email: form.email });

      if (response.data.success) {
        setOtpSent(true);
        setErrors([]);
      } else {
        setErrors([response.data.message || 'Failed to send OTP. Please try again.']);
      }
    } catch (err) {
      console.error('OTP send error:', err);

      if (err.response) {
        if (err.response.data && err.response.data.message) {
          setErrors([err.response.data.message]);
        } else {
          setErrors(['Failed to send OTP. Please try again.']);
        }
      } else {
        setErrors(['Unable to connect to the server. Please check your connection.']);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const verifyAndRegister = async (e) => {
    e.preventDefault();

    if (!otp || otp.length !== 4) {
      setErrors(['Please enter a valid 4-digit OTP']);
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await api.post("/api/register/verify-and-register", {
        ...form,
        otp
      });

      if (response.data.success) {
        navigate('/login', {
          state: {
            message: 'Registration successful! Please log in.',
            isSuccess: true
          }
        });
      } else {
        setErrors([response.data.message || 'Registration failed. Please try again.']);
      }
    } catch (err) {
      console.error('Registration error:', err);

      if (err.response) {
        if (err.response.data && Array.isArray(err.response.data.errors)) {
          setErrors(err.response.data.errors);
        } else if (err.response.data && err.response.data.message) {
          setErrors([err.response.data.message]);
        } else {
          setErrors(['An error occurred during registration. Please try again.']);
        }
      } else {
        setErrors(['Unable to connect to the server. Please check your connection.']);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="register-container">
      <h2>Create an Account</h2>
      
      {errors.length > 0 && (
        <div className="error-messages">
          {errors.map((error, index) => (
            <div key={index} className="error-message">
              {error}
            </div>
          ))}
        </div>
      )}
      
      <form onSubmit={otpSent ? verifyAndRegister : sendOTP} className="register-form">
        <div className="form-group">
          <label htmlFor="name">Full Name</label>
          <input
            id="name"
            name="name"
            type="text"
            placeholder="Enter your full name"
            value={form.name}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            placeholder="Enter your email"
            value={form.email}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            name="password"
            type="password"
            placeholder="Create a password (min 6 characters)"
            value={form.password}
            onChange={handleInputChange}
            className={!passwordMatch ? 'input-error' : ''}
            required
            minLength="6"
          />
        </div>

        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password</label>
          <input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            placeholder="Confirm your password"
            value={form.confirmPassword}
            onChange={handleInputChange}
            className={!passwordMatch ? 'input-error' : ''}
            required
          />
          {!passwordMatch && (
            <span className="error-text">Passwords do not match</span>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="gender">Gender</label>
          <select
            id="gender"
            name="gender"
            value={form.gender}
            onChange={handleInputChange}
            required
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="phone">Phone Number</label>
          <input
            id="phone"
            name="phone"
            type="tel"
            placeholder="Enter your phone number"
            value={form.phone}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="dob">Date of Birth</label>
          <input
            id="dob"
            name="dob"
            type="date"
            value={form.dob}
            onChange={handleInputChange}
            required
            max={new Date().toISOString().split('T')[0]}
          />
        </div>

        <div className="form-group">
          <label htmlFor="address">Address</label>
          <textarea
            id="address"
            name="address"
            placeholder="Enter your full address"
            value={form.address}
            onChange={handleInputChange}
            rows="3"
            required
          />
        </div>

        {otpSent && (
          <>
            <div className="form-group">
              <label htmlFor="otp">OTP</label>
              <input
                id="otp"
                name="otp"
                type="text"
                placeholder="Enter 4-digit OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                maxLength="4"
                required
              />
            </div>
            <div className="form-group">
              <button
                type="button"
                className="resend-otp-button"
                onClick={sendOTP}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Sending...' : 'Resend OTP'}
              </button>
            </div>
          </>
        )}

        <button
          type="submit"
          className="register-button"
          disabled={isSubmitting}
        >
          {isSubmitting ? (otpSent ? 'Verifying...' : 'Sending OTP...') : (otpSent ? 'Verify & Register' : 'Send OTP')}
        </button>
      </form>
      
      <div className="login-link">
        Already have an account? <a href="/login">Log in</a>
      </div>
    </div>
  );
}

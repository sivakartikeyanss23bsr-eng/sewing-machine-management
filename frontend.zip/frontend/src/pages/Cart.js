import { useEffect, useState } from "react";
import api from "../api";

function Cart() {
  const userId = localStorage.getItem("user_id");
  const [cart, setCart] = useState([]);

  useEffect(() => {
    api.get(`/cart/${userId}`).then(res => setCart(res.data));
  }, [userId]);

  const removeItem = async (cartId) => {
    await api.delete(`/api/cart/remove/${cartId}`);
    setCart(cart.filter(item => item.cart_id !== cartId));
  };

  const totalAmount = cart.reduce((sum, item) => sum + Number(item.total), 0);

  return (
    <div className="container">
      <h2>Your Cart</h2>

      {cart.map(item => (
        <div key={item.cart_id} className="card">
          <img src={item.image_url} width="100" />
          <h4>{item.name}</h4>
          <p>Price: ₹{item.price}</p>
          <p>Qty: {item.quantity}</p>
          <p>Total: ₹{item.total}</p>

          <button onClick={() => removeItem(item.cart_id)}>
            Remove
          </button>
        </div>
      ))}

      <h3>Grand Total: ₹{totalAmount}</h3>

      <button disabled={cart.length === 0}>
        Buy Now
      </button>
    </div>
  );
}

export default Cart;

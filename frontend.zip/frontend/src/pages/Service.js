import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

function Service() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    machine_model: "",
    purchase_date: "",
    complaint: ""
  });
  const [menuOpen, setMenuOpen] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submitService = async () => {
    const { name, email, phone, machine_model, purchase_date, complaint } = form;

    if (!name || !email || !phone || !machine_model || !purchase_date || !complaint) {
      alert("Please fill all fields");
      return;
    }

    await api.post("/services", form);
    alert("Service request submitted successfully");

    setForm({
      name: "",
      email: "",
      phone: "",
      machine_model: "",
      purchase_date: "",
      complaint: ""
    });
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', fontFamily: 'Arial, sans-serif' }}>
      {menuOpen && (
        <aside className="sidebar" style={{ width: '150px', padding: '1rem', backgroundColor: '#f5f5f5', borderRight: '1px solid #bbb', position: 'fixed', left: 0, top: 0, height: '100vh', zIndex: 1000, boxShadow: '2px 0 5px rgba(0,0,0,0.1)' }}>
          <h3 style={{ marginBottom: '1rem', textAlign: 'center', color: '#333' }}>Menu</h3>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            <li style={{ marginBottom: '1rem' }}>
              <button onClick={() => { navigate('/'); setMenuOpen(false); }} style={{ width: '100%', padding: '0.5rem', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', color: '#333' }}>Home</button>
            </li>
            <li style={{ marginBottom: '1rem' }}>
              <button onClick={() => { navigate('/products'); setMenuOpen(false); }} style={{ width: '100%', padding: '0.5rem', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', color: '#333' }}>Products</button>
            </li>
            <li style={{ marginBottom: '1rem' }}>
              <button onClick={() => { navigate('/cart'); setMenuOpen(false); }} style={{ width: '100%', padding: '0.5rem', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', color: '#333' }}>Cart</button>
            </li>
            <li style={{ marginBottom: '1rem' }}>
              <button onClick={() => { navigate('/orders'); setMenuOpen(false); }} style={{ width: '100%', padding: '0.5rem', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', color: '#333' }}>Orders</button>
            </li>
            <li style={{ marginBottom: '1rem' }}>
              <button onClick={() => { navigate('/service'); setMenuOpen(false); }} style={{ width: '100%', padding: '0.5rem', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', color: '#333' }}>Service</button>
            </li>
          </ul>
        </aside>
      )}

      <main style={{ flex: 1, padding: '1rem', marginLeft: menuOpen ? '150px' : '0', maxWidth: '1200px', margin: '0 auto' }}>
        <div className="container">
          <h2>Service Request</h2>

          <input name="name" placeholder="Name" value={form.name} onChange={handleChange} />
          <input name="email" placeholder="Email" value={form.email} onChange={handleChange} />
          <input name="phone" placeholder="Phone Number" value={form.phone} onChange={handleChange} />
          <input name="machine_model" placeholder="Machine Model" value={form.machine_model} onChange={handleChange} />
          <input type="date" name="purchase_date" value={form.purchase_date} onChange={handleChange} />
          <textarea name="complaint" placeholder="Describe the issue" value={form.complaint} onChange={handleChange}></textarea>

          <button onClick={submitService}>Submit Request</button>
        </div>
      </main>
    </div>
  );
}

export default Service;

import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import api from "../api";

function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    email: "",
    password: ""
  });
  const [errors, setErrors] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
    if (errors.length > 0) {
      setErrors([]);
    }
  };

  const validateForm = () => {
    const validationErrors = [];
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      validationErrors.push("Valid email is required");
    }
    if (!form.password) {
      validationErrors.push("Password is required");
    }
    setErrors(validationErrors);
    return validationErrors.length === 0;
  };

  const submitLogin = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      const response = await api.post("/api/auth/login", form);
      
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('role', response.data.role);
        navigate('/home');
      } else {
        setErrors(['Login failed. Please try again.']);
      }
    } catch (err) {
      console.error('Login error:', err);
      
      if (err.response) {
        if (err.response.data && err.response.data.message) {
          setErrors([err.response.data.message]);
        } else {
          setErrors(['Invalid credentials']);
        }
      } else {
        setErrors(['Unable to connect to the server. Please check your connection.']);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container">
      <h2>Login</h2>
      
      {errors.length > 0 && (
        <div className="error-messages">
          {errors.map((error, index) => (
            <div key={index} className="error-message">
              {error}
            </div>
          ))}
        </div>
      )}
      
      <form onSubmit={submitLogin}>
        <input
          name="email"
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={handleInputChange}
          required
        />
        <input
          name="password"
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={handleInputChange}
          required
        />
        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Logging in...' : 'Login'}
        </button>
      </form>
      
      <div className="register-link">
        Don't have an account? <a href="/register">Register</a>
      </div>
    </div>
  );
}
export default Login;

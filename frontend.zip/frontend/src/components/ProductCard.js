import api from "../api";

function ProductCard({ product }) {
  const userId = localStorage.getItem("user_id");

  const addToCart = async () => {
    await api.post("/api/cart/add", {
      user_id: userId,
      product_id: product.product_id,
      quantity: 1
    });
    alert("Added to cart");
  };

  return (
    <div className="card">
      <img src={product.image_url} />
      <h4>{product.name}</h4>
      <p>₹{product.price}</p>
      <button onClick={addToCart}>Add to Cart</button>
    </div>
  );
}

export default ProductCard;

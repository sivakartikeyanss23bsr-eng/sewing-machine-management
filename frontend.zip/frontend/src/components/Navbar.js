import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import '../styles/Navbar.css';

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  // Close menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  // Menu items
  const menuItems = [
    { path: "/", name: "Home" },
    { path: "/products", name: "Products" },
    { path: "/cart", name: "Cart" },
    { path: "/orders", name: "Orders" },
    { path: "/service", name: "Services" }
  ];

  return (
    <header className="header">
      <div className="hamburger-menu" onClick={() => setIsOpen(!isOpen)}>
        <div className={`hamburger-line ${isOpen ? 'open' : ''}`}></div>
        <div className={`hamburger-line ${isOpen ? 'open' : ''}`}></div>
        <div className={`hamburger-line ${isOpen ? 'open' : ''}`}></div>
      </div>
      
      <h1 className="logo">Sewing Store</h1>
      
      <nav className={`nav-menu ${isOpen ? 'open' : ''}`}>
        <ul className="nav-list">
          {menuItems.map((item) => (
            <li key={item.path} className="nav-item">
              <Link 
                to={item.path} 
                className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
              >
                {item.name}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* Overlay to close menu when clicking outside */}
      <div className={`menu-overlay ${isOpen ? 'open' : ''}`} onClick={() => setIsOpen(false)}></div>
    </header>
  );
}

export default Navbar;

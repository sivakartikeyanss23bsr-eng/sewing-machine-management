import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminRoute from "./AdminRoute";
import UserRoute from "./UserRoute";
import Navbar from "./components/Navbar";

import Home from "./pages/Home";
import FirstHome from "./pages/FirstHome";
import UserLogin from "./pages/UserLogin";
import AdminLogin from "./pages/AdminLogin";
import Register from "./pages/Register";
import AdminDashboard from "./pages/AdminDashboard";
import Service from "./pages/Service";
import Products from "./pages/Products";
import Cart from "./pages/Cart";
import Orders from "./pages/Orders";

function App() {
  return (
    <Router>

      {/* Navbar should be OUTSIDE Routes */}
      <Navbar />

      <Routes>

        <Route path="/" element={<FirstHome />} />
        <Route path="/login" element={<UserLogin />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/home" element={<UserRoute><Home /></UserRoute>} />
        <Route path="/service" element={<Service />} />
        <Route path="/Products" element={<Products />}/>
        <Route path="/Cart" element={<Cart />}/>
        <Route path="/Orders" element={<Orders />}/>
        <Route path="/admin"element={<AdminRoute><AdminDashboard /></AdminRoute>}
        />

      </Routes>
    </Router>
  );
}

export default App;

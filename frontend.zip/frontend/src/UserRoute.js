import { Navigate } from "react-router-dom";

function UserRoute({ children }) {
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  // Not logged in
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // Logged in but not user
  if (role !== "user") {
    return <Navigate to="/" replace />;
  }

  return children;
}

export default UserRoute;
